import express from "express";
import bodyParser from "body-parser";
import { JSDOM } from "jsdom";
import multer from 'multer';



const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

const upload = multer(); 

app.get("/",(req,res)=>{
    res.render("Entryy.ejs");
})


app.use(express.static("public"));


app.get("/Dash",(req,res)=>{
    res.render("Dash.ejs");
})

app.get("/Contact",(req,res)=>{
    res.render("Contact.ejs");
})

app.get("/About",(req,res)=>{
    res.render("About.ejs");
})

// const form = document.getElementById("myForm");
// const datas = [];
// form.addEventListener("submit",function(event){
//     event.preventDefault(); 
//     const name = document.getElementById("nameInput").value;
//     const email = document.getElementById("emailInput").value;
//     const phno = document.getElementById("phonenumberinput").value;


//     const formdata = {
//         name,email,phno
//     }
//     datas.push(formdata);
//     console.log(formdata); // Check in browser console

//     form.reset(); // Clear the form
//     const modal = bootstrap.Modal.getInstance(document.getElementById('etcModal'));
//     modal.hide();
// })

// In your index.js (Node.js)

const datas = [
    {
      id:1,
      name: 'Chloe',
      email: 'chloe.lane@gmail.com',
      phone: '9876543210',
      role: 'UI/UX Designer'
    },
    {
        id:2,
        name: 'Ella',
        email: 'ella.smith@gmail.com',
        phone: '8222233333',
        role: 'Backend Developer'
      },
      {
        id:3,
        name: 'Bob',
        email: 'bob.jenkins@gmail.com',
        phone: '9123456780',
        role: 'Web Developer'
      },
  ];

  let lastId = 3;

  



















  app.post("/submit", upload.none(), (req, res) => {
    console.log("Submitted Value : ", req.body);
    const newid = lastId+1; 
  
     const formdata = {
      id : newid,
      name : req.body.name,
      email : req.body.email,
      phone : req.body.phone,
      role : req.body.role
    }
    console.log(formdata);
    lastId = newid;
    datas.push(formdata);
    console.log("All submissions so far:", datas);
    res.redirect("/Dash");
  });
  
  
  app.patch("/update/:id",(req,res)=>{
    console.log("Gowtham");
    console.log("Submitted Value : ", req.body);
    const ids = parseInt(req.params.id);
    const olddata = datas.find((post)=>post.id===ids);

    olddata.name = req.body.name || olddata.name,
    olddata.email = req.body.email || olddata.email,
    olddata.phone = req.body.phone || olddata.phone,
    olddata.role = req.body.role || olddata.role

    console.log(olddata);
    res.json({ message: "Data updated successfully", updatedData: olddata });

  })

  app.delete("/delete/:id",(req,res)=>{
    console.log("Gowtham");
    const ids = parseInt(req.params.id);
    const ind = datas.findIndex((post)=>post.id===ids)
    
    if(ind>-1)
      {
        const deleted = datas.splice(ind,1);
        //console.log({error:`Element ${ids} is deleted`});
        console.log("Deleted user:", deleted);
        res.json({message:"User is Deleted"});
        
      }
      else{
        console.log({ error: `Element ${ids} not found` });
        res.status(404).json({ error: `User with id ${ids} not found` });
      }
      console.log(datas)
  })

  app.get("/candidates", (req, res) => {
    res.json(datas); // or whatever your candidates array is called
  });




app.listen(port, () => {
    console.log(`API is running at http://localhost:${port}`);
  });